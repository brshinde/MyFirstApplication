package com.example.root.myfirstapplication;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

/**
 * Created by root on 18/1/19.
 */

public class Addition extends AppCompatActivity implements View.OnClickListener {
    EditText e1,e2,e3;
    Button b1,b2;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.addition);
        e1=findViewById(R.id.num1);
        e2=findViewById(R.id.num2);
        e3=findViewById(R.id.result);
        b1=findViewById(R.id.add);
        b2=findViewById(R.id.sub);

        b1.setOnClickListener(this);
        b2.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {

        if(v.getId()==R.id.add)
        {

    String s1=e1.getText().toString();
    String s2=e2.getText().toString();
    int a=Integer.parseInt(s1);
    int b=Integer.parseInt(s2);
    int c = a+b;
    String s3 = String.valueOf(c);
    e3.setText(s3);

    }
    else
        {
            String s1=e1.getText().toString();
            String s2=e2.getText().toString();
            int a=Integer.parseInt(s1);
            int b=Integer.parseInt(s2);
            int c = a-b;
            String s3 = String.valueOf(c);
            e3.setText(s3);

        }
    }
}
